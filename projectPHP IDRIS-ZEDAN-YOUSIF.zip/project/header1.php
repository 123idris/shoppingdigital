<header class="header">

   <div class="flex">

      <a href="#" class="logo">Digital Devices</a>

      <nav class="navbar">
        
      <a href="user_view.php">view products</a>
      
   
      </nav>

      <?php
      
      $select_rows = mysqli_query($conn, "SELECT * FROM `list`") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);

      ?>

      <a href="list.php" class="list">LIST <span><?php echo $row_count; ?></span> </a>

      <div id="menu-btn" class="fas fa-bars"></div>
      <nav class="navbar">
        
      <a href="logout.php" >logout</a>
      </nav>
      

   </div>

</header>