<?php

$conn = mysqli_connect('localhost','root','0000','shop_db');

?>